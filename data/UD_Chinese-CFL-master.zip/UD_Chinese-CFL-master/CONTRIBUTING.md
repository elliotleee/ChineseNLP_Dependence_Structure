# Contributing

Please do not make pull requests against master, any such pull requests will be
closed. Pull requests against the dev branch are accepted in some treebanks but
not in others - check the Contributing line in the README file!

For full details on the branch policy see
[here](http://universaldependencies.org/release_checklist.html#repository-branches).
